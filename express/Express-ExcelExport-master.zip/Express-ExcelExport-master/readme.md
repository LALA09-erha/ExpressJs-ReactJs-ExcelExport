# CRUD WITH EXPRESS JS X Node JS

Profile : [LALA09-erha](https://github.com/LALA09-erha)

PROJECT DONEEE~~~!

